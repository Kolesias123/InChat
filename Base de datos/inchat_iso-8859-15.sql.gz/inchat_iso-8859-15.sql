-- phpMyAdmin SQL Dump
-- version 3.5.0
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generaci�n: 17-05-2012 a las 20:58:38
-- Versi�n del servidor: 5.5.16
-- Versi�n de PHP: 5.4.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES latin1 */;

--
-- Base de datos: `inchat`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `site_cache`
--

CREATE TABLE IF NOT EXISTS `site_cache` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `page` varchar(50) NOT NULL,
  `time` int(100) NOT NULL DEFAULT '12',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `site_config`
--

CREATE TABLE IF NOT EXISTS `site_config` (
  `var` varchar(100) NOT NULL,
  `result` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Configuracion del sitio';

--
-- Volcado de datos para la tabla `site_config`
--

INSERT INTO `site_config` (`var`, `result`) VALUES
('site_name', 'InChat'),
('site_separation', '~'),
('site_slogan', 'Salas de chat simples y personalizadas.'),
('site_charset', 'iso-8859-15'),
('site_language', 'es'),
('site_description', 'InChat te permite crear de forma gratuita salas de chat en HTML 5 para poder usarlas en tus sitios web.'),
('site_keywords', 'infosmart, beatrock, chat, html5, inchat, salas de chateo, social, socializar, plugin, p�f¡ginas web, paginas, aplicaciones, miembros'),
('site_analytics', ''),
('site_state', 'open'),
('site_visits', '4'),
('site_favicon', 'favicon.ico'),
('site_logo', 'logo.png'),
('site_version', '1.0.0'),
('site_revision', 'de 2011'),
('site_author', 'Iv�n Bravo Bravo'),
('site_publisher', 'InfoSmart'),
('site_mobile', 'false'),
('site_sitemap', 'true'),
('site_rss', 'true'),
('site_translate', 'false'),
('site_smart_translate', 'false'),
('site_bottom_javascript', 'false'),
('site_notes', ''),
('session_alias', 'inchat_'),
('cookie_alias', 'inchat_'),
('cookie_duration', '300'),
('cookie_domain', ''),
('server_host', 'http://localhost:1797'),
('users_online', '0'),
('files_path', '../resources/inchat/files');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `site_countrys`
--

CREATE TABLE IF NOT EXISTS `site_countrys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isoNum` smallint(6) DEFAULT NULL,
  `code2` char(2) DEFAULT NULL,
  `code3` char(3) DEFAULT NULL,
  `name` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=241 ;

--
-- Volcado de datos para la tabla `site_countrys`
--

INSERT INTO `site_countrys` (`id`, `isoNum`, `code2`, `code3`, `name`) VALUES
(1, 4, 'AF', 'AFG', 'Afganist�f¡n'),
(2, 248, 'AX', 'ALA', 'Islas Gland'),
(3, 8, 'AL', 'ALB', 'Albania'),
(4, 276, 'DE', 'DEU', 'Alemania'),
(5, 20, 'AD', 'AND', 'Andorra'),
(6, 24, 'AO', 'AGO', 'Angola'),
(7, 660, 'AI', 'AIA', 'Anguilla'),
(8, 10, 'AQ', 'ATA', 'Ant�f¡rtida'),
(9, 28, 'AG', 'ATG', 'Antigua y Barbuda'),
(10, 530, 'AN', 'ANT', 'Antillas Holandesas'),
(11, 682, 'SA', 'SAU', 'Arabia Saud�f­'),
(12, 12, 'DZ', 'DZA', 'Argelia'),
(13, 32, 'AR', 'ARG', 'Argentina'),
(14, 51, 'AM', 'ARM', 'Armenia'),
(15, 533, 'AW', 'ABW', 'Aruba'),
(16, 36, 'AU', 'AUS', 'Australia'),
(17, 40, 'AT', 'AUT', 'Austria'),
(18, 31, 'AZ', 'AZE', 'Azerbaiy�f¡n'),
(19, 44, 'BS', 'BHS', 'Bahamas'),
(20, 48, 'BH', 'BHR', 'Bahr�f©in'),
(21, 50, 'BD', 'BGD', 'Bangladesh'),
(22, 52, 'BB', 'BRB', 'Barbados'),
(23, 112, 'BY', 'BLR', 'Bielorrusia'),
(24, 56, 'BE', 'BEL', 'B�f©lgica'),
(25, 84, 'BZ', 'BLZ', 'Belice'),
(26, 204, 'BJ', 'BEN', 'Benin'),
(27, 60, 'BM', 'BMU', 'Bermudas'),
(28, 64, 'BT', 'BTN', 'Bhut�f¡n'),
(29, 68, 'BO', 'BOL', 'Bolivia'),
(30, 70, 'BA', 'BIH', 'Bosnia y Herzegovina'),
(31, 72, 'BW', 'BWA', 'Botsuana'),
(32, 74, 'BV', 'BVT', 'Isla Bouvet'),
(33, 76, 'BR', 'BRA', 'Brasil'),
(34, 96, 'BN', 'BRN', 'Brun�f©i'),
(35, 100, 'BG', 'BGR', 'Bulgaria'),
(36, 854, 'BF', 'BFA', 'Burkina Faso'),
(37, 108, 'BI', 'BDI', 'Burundi'),
(38, 132, 'CV', 'CPV', 'Cabo Verde'),
(39, 136, 'KY', 'CYM', 'Islas Caim�f¡n'),
(40, 116, 'KH', 'KHM', 'Camboya'),
(41, 120, 'CM', 'CMR', 'Camer�fºn'),
(42, 124, 'CA', 'CAN', 'Canad�f¡'),
(43, 140, 'CF', 'CAF', 'Rep�fºblica Centroafricana'),
(44, 148, 'TD', 'TCD', 'Chad'),
(45, 203, 'CZ', 'CZE', 'Rep�fºblica Checa'),
(46, 152, 'CL', 'CHL', 'Chile'),
(47, 156, 'CN', 'CHN', 'China'),
(48, 196, 'CY', 'CYP', 'Chipre'),
(49, 162, 'CX', 'CXR', 'Isla de Navidad'),
(50, 336, 'VA', 'VAT', 'Ciudad del Vaticano'),
(51, 166, 'CC', 'CCK', 'Islas Cocos'),
(52, 170, 'CO', 'COL', 'Colombia'),
(53, 174, 'KM', 'COM', 'Comoras'),
(54, 180, 'CD', 'COD', 'Rep�fºblica Democr�f¡tica del Congo'),
(55, 178, 'CG', 'COG', 'Congo'),
(56, 184, 'CK', 'COK', 'Islas Cook'),
(57, 408, 'KP', 'PRK', 'Corea del Norte'),
(58, 410, 'KR', 'KOR', 'Corea del Sur'),
(59, 384, 'CI', 'CIV', 'Costa de Marfil'),
(60, 188, 'CR', 'CRI', 'Costa Rica'),
(61, 191, 'HR', 'HRV', 'Croacia'),
(62, 192, 'CU', 'CUB', 'Cuba'),
(63, 208, 'DK', 'DNK', 'Dinamarca'),
(64, 212, 'DM', 'DMA', 'Dominica'),
(65, 214, 'DO', 'DOM', 'Rep�fºblica Dominicana'),
(66, 218, 'EC', 'ECU', 'Ecuador'),
(67, 818, 'EG', 'EGY', 'Egipto'),
(68, 222, 'SV', 'SLV', 'El Salvador'),
(69, 784, 'AE', 'ARE', 'Emiratos �frabes Unidos'),
(70, 232, 'ER', 'ERI', 'Eritrea'),
(71, 703, 'SK', 'SVK', 'Eslovaquia'),
(72, 705, 'SI', 'SVN', 'Eslovenia'),
(73, 724, 'ES', 'ESP', 'Espa�f±a'),
(74, 581, 'UM', 'UMI', 'Islas ultramarinas de Estados Unidos'),
(75, 840, 'US', 'USA', 'Estados Unidos'),
(76, 233, 'EE', 'EST', 'Estonia'),
(77, 231, 'ET', 'ETH', 'Etiop�f­a'),
(78, 234, 'FO', 'FRO', 'Islas Feroe'),
(79, 608, 'PH', 'PHL', 'Filipinas'),
(80, 246, 'FI', 'FIN', 'Finlandia'),
(81, 242, 'FJ', 'FJI', 'Fiyi'),
(82, 250, 'FR', 'FRA', 'Francia'),
(83, 266, 'GA', 'GAB', 'Gab�f³n'),
(84, 270, 'GM', 'GMB', 'Gambia'),
(85, 268, 'GE', 'GEO', 'Georgia'),
(86, 239, 'GS', 'SGS', 'Islas Georgias del Sur y Sandwich del Sur'),
(87, 288, 'GH', 'GHA', 'Ghana'),
(88, 292, 'GI', 'GIB', 'Gibraltar'),
(89, 308, 'GD', 'GRD', 'Granada'),
(90, 300, 'GR', 'GRC', 'Grecia'),
(91, 304, 'GL', 'GRL', 'Groenlandia'),
(92, 312, 'GP', 'GLP', 'Guadalupe'),
(93, 316, 'GU', 'GUM', 'Guam'),
(94, 320, 'GT', 'GTM', 'Guatemala'),
(95, 254, 'GF', 'GUF', 'Guayana Francesa'),
(96, 324, 'GN', 'GIN', 'Guinea'),
(97, 226, 'GQ', 'GNQ', 'Guinea Ecuatorial'),
(98, 624, 'GW', 'GNB', 'Guinea-Bissau'),
(99, 328, 'GY', 'GUY', 'Guyana'),
(100, 332, 'HT', 'HTI', 'Hait�f­'),
(101, 334, 'HM', 'HMD', 'Islas Heard y McDonald'),
(102, 340, 'HN', 'HND', 'Honduras'),
(103, 344, 'HK', 'HKG', 'Hong Kong'),
(104, 348, 'HU', 'HUN', 'Hungr�f­a'),
(105, 356, 'IN', 'IND', 'India'),
(106, 360, 'ID', 'IDN', 'Indonesia'),
(107, 364, 'IR', 'IRN', 'Ir�f¡n'),
(108, 368, 'IQ', 'IRQ', 'Iraq'),
(109, 372, 'IE', 'IRL', 'Irlanda'),
(110, 352, 'IS', 'ISL', 'Islandia'),
(111, 376, 'IL', 'ISR', 'Israel'),
(112, 380, 'IT', 'ITA', 'Italia'),
(113, 388, 'JM', 'JAM', 'Jamaica'),
(114, 392, 'JP', 'JPN', 'Jap�f³n'),
(115, 400, 'JO', 'JOR', 'Jordania'),
(116, 398, 'KZ', 'KAZ', 'Kazajst�f¡n'),
(117, 404, 'KE', 'KEN', 'Kenia'),
(118, 417, 'KG', 'KGZ', 'Kirguist�f¡n'),
(119, 296, 'KI', 'KIR', 'Kiribati'),
(120, 414, 'KW', 'KWT', 'Kuwait'),
(121, 418, 'LA', 'LAO', 'Laos'),
(122, 426, 'LS', 'LSO', 'Lesotho'),
(123, 428, 'LV', 'LVA', 'Letonia'),
(124, 422, 'LB', 'LBN', 'L�f­bano'),
(125, 430, 'LR', 'LBR', 'Liberia'),
(126, 434, 'LY', 'LBY', 'Libia'),
(127, 438, 'LI', 'LIE', 'Liechtenstein'),
(128, 440, 'LT', 'LTU', 'Lituania'),
(129, 442, 'LU', 'LUX', 'Luxemburgo'),
(130, 446, 'MO', 'MAC', 'Macao'),
(131, 807, 'MK', 'MKD', 'ARY Macedonia'),
(132, 450, 'MG', 'MDG', 'Madagascar'),
(133, 458, 'MY', 'MYS', 'Malasia'),
(134, 454, 'MW', 'MWI', 'Malawi'),
(135, 462, 'MV', 'MDV', 'Maldivas'),
(136, 466, 'ML', 'MLI', 'Mal�f­'),
(137, 470, 'MT', 'MLT', 'Malta'),
(138, 238, 'FK', 'FLK', 'Islas Malvinas'),
(139, 580, 'MP', 'MNP', 'Islas Marianas del Norte'),
(140, 504, 'MA', 'MAR', 'Marruecos'),
(141, 584, 'MH', 'MHL', 'Islas Marshall'),
(142, 474, 'MQ', 'MTQ', 'Martinica'),
(143, 480, 'MU', 'MUS', 'Mauricio'),
(144, 478, 'MR', 'MRT', 'Mauritania'),
(145, 175, 'YT', 'MYT', 'Mayotte'),
(146, 484, 'MX', 'MEX', 'M�f©xico'),
(147, 583, 'FM', 'FSM', 'Micronesia'),
(148, 498, 'MD', 'MDA', 'Moldavia'),
(149, 492, 'MC', 'MCO', 'M�f³naco'),
(150, 496, 'MN', 'MNG', 'Mongolia'),
(151, 500, 'MS', 'MSR', 'Montserrat'),
(152, 508, 'MZ', 'MOZ', 'Mozambique'),
(153, 104, 'MM', 'MMR', 'Myanmar'),
(154, 516, 'NA', 'NAM', 'Namibia'),
(155, 520, 'NR', 'NRU', 'Nauru'),
(156, 524, 'NP', 'NPL', 'Nepal'),
(157, 558, 'NI', 'NIC', 'Nicaragua'),
(158, 562, 'NE', 'NER', 'N�f­ger'),
(159, 566, 'NG', 'NGA', 'Nigeria'),
(160, 570, 'NU', 'NIU', 'Niue'),
(161, 574, 'NF', 'NFK', 'Isla Norfolk'),
(162, 578, 'NO', 'NOR', 'Noruega'),
(163, 540, 'NC', 'NCL', 'Nueva Caledonia'),
(164, 554, 'NZ', 'NZL', 'Nueva Zelanda'),
(165, 512, 'OM', 'OMN', 'Om�f¡n'),
(166, 528, 'NL', 'NLD', 'Pa�f­ses Bajos'),
(167, 586, 'PK', 'PAK', 'Pakist�f¡n'),
(168, 585, 'PW', 'PLW', 'Palau'),
(169, 275, 'PS', 'PSE', 'Palestina'),
(170, 591, 'PA', 'PAN', 'Panam�f¡'),
(171, 598, 'PG', 'PNG', 'Pap�fºa Nueva Guinea'),
(172, 600, 'PY', 'PRY', 'Paraguay'),
(173, 604, 'PE', 'PER', 'Per�fº'),
(174, 612, 'PN', 'PCN', 'Islas Pitcairn'),
(175, 258, 'PF', 'PYF', 'Polinesia Francesa'),
(176, 616, 'PL', 'POL', 'Polonia'),
(177, 620, 'PT', 'PRT', 'Portugal'),
(178, 630, 'PR', 'PRI', 'Puerto Rico'),
(179, 634, 'QA', 'QAT', 'Qatar'),
(180, 826, 'GB', 'GBR', 'Reino Unido'),
(181, 638, 'RE', 'REU', 'Reuni�f³n'),
(182, 646, 'RW', 'RWA', 'Ruanda'),
(183, 642, 'RO', 'ROU', 'Rumania'),
(184, 643, 'RU', 'RUS', 'Rusia'),
(185, 732, 'EH', 'ESH', 'Sahara Occidental'),
(186, 90, 'SB', 'SLB', 'Islas Salom�f³n'),
(187, 882, 'WS', 'WSM', 'Samoa'),
(188, 16, 'AS', 'ASM', 'Samoa Americana'),
(189, 659, 'KN', 'KNA', 'San Crist�f³bal y Nevis'),
(190, 674, 'SM', 'SMR', 'San Marino'),
(191, 666, 'PM', 'SPM', 'San Pedro y Miquel�f³n'),
(192, 670, 'VC', 'VCT', 'San Vicente y las Granadinas'),
(193, 654, 'SH', 'SHN', 'Santa Helena'),
(194, 662, 'LC', 'LCA', 'Santa Luc�f­a'),
(195, 678, 'ST', 'STP', 'Santo Tom�f© y Pr�f­ncipe'),
(196, 686, 'SN', 'SEN', 'Senegal'),
(197, 891, 'CS', 'SCG', 'Serbia y Montenegro'),
(198, 690, 'SC', 'SYC', 'Seychelles'),
(199, 694, 'SL', 'SLE', 'Sierra Leona'),
(200, 702, 'SG', 'SGP', 'Singapur'),
(201, 760, 'SY', 'SYR', 'Siria'),
(202, 706, 'SO', 'SOM', 'Somalia'),
(203, 144, 'LK', 'LKA', 'Sri Lanka'),
(204, 748, 'SZ', 'SWZ', 'Suazilandia'),
(205, 710, 'ZA', 'ZAF', 'Sud�f¡frica'),
(206, 736, 'SD', 'SDN', 'Sud�f¡n'),
(207, 752, 'SE', 'SWE', 'Suecia'),
(208, 756, 'CH', 'CHE', 'Suiza'),
(209, 740, 'SR', 'SUR', 'Surinam'),
(210, 744, 'SJ', 'SJM', 'Svalbard y Jan Mayen'),
(211, 764, 'TH', 'THA', 'Tailandia'),
(212, 158, 'TW', 'TWN', 'Taiw�f¡n'),
(213, 834, 'TZ', 'TZA', 'Tanzania'),
(214, 762, 'TJ', 'TJK', 'Tayikist�f¡n'),
(215, 86, 'IO', 'IOT', 'Territorio Brit�f¡nico del Oc�f©ano �fndico'),
(216, 260, 'TF', 'ATF', 'Territorios Australes Franceses'),
(217, 626, 'TL', 'TLS', 'Timor Oriental'),
(218, 768, 'TG', 'TGO', 'Togo'),
(219, 772, 'TK', 'TKL', 'Tokelau'),
(220, 776, 'TO', 'TON', 'Tonga'),
(221, 780, 'TT', 'TTO', 'Trinidad y Tobago'),
(222, 788, 'TN', 'TUN', 'T�fºnez'),
(223, 796, 'TC', 'TCA', 'Islas Turcas y Caicos'),
(224, 795, 'TM', 'TKM', 'Turkmenist�f¡n'),
(225, 792, 'TR', 'TUR', 'Turqu�f­a'),
(226, 798, 'TV', 'TUV', 'Tuvalu'),
(227, 804, 'UA', 'UKR', 'Ucrania'),
(228, 800, 'UG', 'UGA', 'Uganda'),
(229, 858, 'UY', 'URY', 'Uruguay'),
(230, 860, 'UZ', 'UZB', 'Uzbekist�f¡n'),
(231, 548, 'VU', 'VUT', 'Vanuatu'),
(232, 862, 'VE', 'VEN', 'Venezuela'),
(233, 704, 'VN', 'VNM', 'Vietnam'),
(234, 92, 'VG', 'VGB', 'Islas V�f­rgenes Brit�f¡nicas'),
(235, 850, 'VI', 'VIR', 'Islas V�f­rgenes de los Estados Unidos'),
(236, 876, 'WF', 'WLF', 'Wallis y Futuna'),
(237, 887, 'YE', 'YEM', 'Yemen'),
(238, 262, 'DJ', 'DJI', 'Yibuti'),
(239, 894, 'ZM', 'ZMB', 'Zambia'),
(240, 716, 'ZW', 'ZWE', 'Zimbabue');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `site_errors`
--

CREATE TABLE IF NOT EXISTS `site_errors` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `code` varchar(100) NOT NULL DEFAULT '000',
  `title` varchar(100) NOT NULL,
  `response` text NOT NULL,
  `file` varchar(300) NOT NULL,
  `function` varchar(100) NOT NULL,
  `line` int(100) NOT NULL,
  `out_file` varchar(300) NOT NULL,
  `more` text NOT NULL,
  `date` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `site_logs`
--

CREATE TABLE IF NOT EXISTS `site_logs` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `logs` text NOT NULL,
  `phpid` varchar(300) NOT NULL,
  `path` varchar(300) NOT NULL,
  `date` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `site_maps`
--

CREATE TABLE IF NOT EXISTS `site_maps` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `page` varchar(100) NOT NULL,
  `lastmod` varchar(50) NOT NULL,
  `changefrec` enum('always','hourly','daily','weekly','monthly','yearly','never') NOT NULL DEFAULT 'always',
  `priority` varchar(10) NOT NULL DEFAULT '1.0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `site_news`
--

CREATE TABLE IF NOT EXISTS `site_news` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `sub_content` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(300) NOT NULL,
  `images` varchar(1000) NOT NULL,
  `author` varchar(60) NOT NULL,
  `date` varchar(100) NOT NULL,
  `comments` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Noticias' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `site_pages`
--

CREATE TABLE IF NOT EXISTS `site_pages` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `request` varchar(300) NOT NULL,
  `page` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `header` enum('true','false') NOT NULL DEFAULT 'true',
  `footer` enum('true','false') NOT NULL DEFAULT 'true',
  `subheader` varchar(100) NOT NULL DEFAULT 'SubHeader',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `site_timers`
--

CREATE TABLE IF NOT EXISTS `site_timers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `action` varchar(100) NOT NULL,
  `time` int(100) NOT NULL,
  `nexttime` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Tareas automaticas del Sitio' AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `site_timers`
--

INSERT INTO `site_timers` (`id`, `action`, `time`, `nexttime`) VALUES
(1, 'optimize_db', 10080, 1334530764),
(2, 'maintenance_db', 44640, 1336604367),
(3, 'backup_db', 20160, 1335135572),
(4, 'maintenance_backups', 44640, 1336604377);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `site_translate`
--

CREATE TABLE IF NOT EXISTS `site_translate` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `var` varchar(100) NOT NULL,
  `original` text NOT NULL,
  `translated` text NOT NULL,
  `language` varchar(10) NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `site_visits`
--

CREATE TABLE IF NOT EXISTS `site_visits` (
  `ip` varchar(100) NOT NULL,
  `host` varchar(150) NOT NULL,
  `agent` text NOT NULL,
  `browser` varchar(100) NOT NULL,
  `referer` varchar(300) NOT NULL,
  `phpid` varchar(300) NOT NULL,
  `type` enum('desktop','mobile','bot') NOT NULL DEFAULT 'desktop',
  `date` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(50) NOT NULL,
  `username` varchar(32) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(48) NOT NULL,
  `photo` varchar(300) NOT NULL,
  `rank` int(2) NOT NULL DEFAULT '1',
  `state` varchar(48) NOT NULL,
  `birthday` varchar(100) NOT NULL,
  `account_birthday` varchar(100) NOT NULL,
  `lastaccess` varchar(100) NOT NULL,
  `lastonline` varchar(100) NOT NULL DEFAULT '0',
  `ip_address` varchar(100) NOT NULL,
  `browser` varchar(100) NOT NULL,
  `agent` varchar(500) NOT NULL,
  `os` varchar(100) NOT NULL,
  `lasthost` varchar(200) NOT NULL,
  `country` varchar(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Usuarios' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_browser`
--

CREATE TABLE IF NOT EXISTS `users_browser` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(50) NOT NULL,
  `hash_secret` varchar(80) NOT NULL,
  `username` varchar(32) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(48) NOT NULL,
  `rank` int(2) NOT NULL DEFAULT '1',
  `birthday` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL DEFAULT 'photo.default',
  `photo_time` int(100) NOT NULL,
  `account_birthday` varchar(100) NOT NULL,
  `lastaccess` varchar(100) NOT NULL,
  `lastonline` varchar(100) NOT NULL DEFAULT '0',
  `ip_address` varchar(100) NOT NULL,
  `browser` varchar(100) NOT NULL,
  `agent` varchar(500) NOT NULL,
  `os` varchar(100) NOT NULL,
  `lasthost` varchar(200) NOT NULL,
  `country` varchar(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Usuarios' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_rooms`
--

CREATE TABLE IF NOT EXISTS `users_rooms` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `ownerId` int(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `in_list` enum('true','false') NOT NULL DEFAULT 'true',
  `options` text NOT NULL,
  `style` text NOT NULL,
  `date` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `wordsfilter`
--

CREATE TABLE IF NOT EXISTS `wordsfilter` (
  `word` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Filtro de Palabras';

--
-- Volcado de datos para la tabla `wordsfilter`
--

INSERT INTO `wordsfilter` (`word`) VALUES
('puto'),
('puta'),
('pendejo'),
('pendeja'),
('pito'),
('verga'),
('pene'),
('vagina'),
('cabron'),
('cabrona'),
('chingada'),
('chingados'),
('mierda'),
('popo'),
('shit'),
('motherfucker'),
('motherfuck'),
('p.u.t.o'),
('p.u.t.h.o'),
('putho'),
('mamawebo'),
('mamahuevo'),
('mmg'),
('putha'),
('putho'),
('pija'),
('dick'),
('bitch'),
('b!tch'),
('dumbass'),
('joto'),
('jotho'),
('asshole'),
('culo');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
